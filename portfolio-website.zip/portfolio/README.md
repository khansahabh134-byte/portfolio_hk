# Portfolio Website

A modern, fully responsive portfolio website built with **HTML5, CSS3, and Vanilla JavaScript only** — no frameworks or libraries.

## Structure
```
portfolio/
├── index.html          Home page
├── about.html           About / education / experience / timeline
├── services.html        Services offered
├── portfolio.html       Projects with filtering
├── skills.html          Animated skill bars + counters
├── testimonials.html    Client reviews
├── blog.html            Blog cards
├── contact.html         Contact form + map placeholder
├── style.css            Single shared stylesheet (design tokens, components, responsive rules)
├── script.js            Single shared script (all interactivity)
└── assets/
    ├── images/          Place real photos/screenshots here (SVG placeholders used by default)
    ├── icons/           Place custom icon assets here (inline SVGs used by default)
    └── fonts/           Place self-hosted font files here if you want to replace Google Fonts CDN
```

## Notes
- Color palette, typography (Space Grotesk / Inter / JetBrains Mono), and all components are defined via CSS custom properties in `style.css` — edit the `:root` block to re-theme instantly.
- Dark/Light mode is saved to `localStorage` under the key `portfolio-theme`.
- All images are inline SVG placeholders so the site works immediately with zero external assets. Swap in real photos by replacing the `<svg>` blocks with `<img src="assets/images/...">`.
- To wire up the contact form to a real backend, replace the `fetch`/submit logic in `script.js` (section 12) with your endpoint call (e.g. Formspree, EmailJS, or your own API).
- Google Fonts is loaded via CDN `@import` in `style.css`. For fully offline use, download the font files into `assets/fonts/` and update the `@font-face` rules.

## Opening the site
Simply open `index.html` in a browser, or serve the folder with any static server:
```
npx serve .
```
